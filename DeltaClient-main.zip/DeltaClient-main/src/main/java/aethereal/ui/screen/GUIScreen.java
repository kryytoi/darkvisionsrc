package aethereal.ui.screen;

import aethereal.core.Category;
import aethereal.core.Delta;
import aethereal.core.Interface;
import aethereal.core.Module;
import aethereal.render.AnimationUtil;
import aethereal.render.ColorUtil;
import aethereal.render.Draw2DProcessor;
import aethereal.render.EasingList;
import aethereal.render.Fonts;
import aethereal.render.ScaleUtil;
import aethereal.render.ScissorUtil;
import aethereal.ui.element.Element;
import aethereal.ui.element.TextField;
import aethereal.util.MathUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.Vector2f;
import net.minecraft.resource.Resource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.joml.Quaternionf;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

public class GUIScreen extends Screen {
    private static final Identifier LOGO_ID = Identifier.of("delta", "darkvis/logobum");

    private static final float PANEL_W = 400.0f;
    private static final float PANEL_H = 240.0f;
    private static final float SIDE_W = 70.0f;
    private static final float SIDE_PAD = 22.0f;
    private static final float SIDE_GAP = 15.0f;
    private static final float RIGHT_PAD = 12.0f;
    private static final float TOP_PAD = 11.0f;
    private static final float PILL_H = 20.0f;
    private static final float PILL_GAP = 2.5f;

    private final TextField a;
    private final AnimationUtil b;
    private final AnimationUtil openAnim;
    private final AnimationUtil cascadeAnim;
    private final AnimationUtil viewAnim;
    private final AnimationUtil settingsScroll;
    private final List<GUIPanel> c;
    private final AnimationUtil[] pillAnim = new AnimationUtil[6];
    private final AnimationUtil[] pillActive = new AnimationUtil[6];
    private String d;
    private int activeCategory = 0;
    private boolean settingsView = false;
    private boolean closing = false;
    private Module selectedModule = null;
    private GUIPanel ghostPanel = null;
    private float lastScale = 1.0f;
    private float lastSlideY = 0.0f;

    private boolean logoLoaded = false;
    private boolean logoWarned = false;
    private int logoTextureId = -1;

    public GUIScreen(Text title) {
        super(title);
        this.a = new TextField(TextField.type.GUI);
        this.b = new AnimationUtil();
        this.openAnim = new AnimationUtil();
        this.cascadeAnim = new AnimationUtil();
        this.viewAnim = new AnimationUtil();
        this.settingsScroll = new AnimationUtil();
        this.c = new ArrayList<>();
        for (int i = 0; i < this.pillAnim.length; i++) {
            this.pillAnim[i] = new AnimationUtil();
            this.pillActive[i] = new AnimationUtil();
        }
        for (Category category : Category.values()) {
            this.c.add(new GUIPanel(category));
        }
        this.a.setPlaceholder("Поиск по модулям");
        if (Interface.mc.currentScreen instanceof GUIScreen) {
            this.openAnim.c(1.0f);
        } else {
            ClientSettings.playOpenSound();
        }
    }

    public static boolean f(GUIPanel panel) {
        return panel.d() != null;
    }

    public static boolean e(GUIPanel panel) {
        return panel.d() != null;
    }

    public static boolean d(GUIPanel panel) {
        return panel.d() != null;
    }

    public static boolean c(GUIPanel panel) {
        return panel.d() != null;
    }

    public static boolean b(GUIPanel panel) {
        return panel.d() != null;
    }

    public static boolean a(GUIPanel panel) {
        return panel.d() != null;
    }

    private float panelX() {
        return (Interface.mc.getWindow().getScaledWidth() - PANEL_W) * 0.5f;
    }

    private float panelY() {
        return (Interface.mc.getWindow().getScaledHeight() - PANEL_H) * 0.5f;
    }

    private float sideX() {
        return panelX() + SIDE_PAD;
    }

    private float contX() {
        return sideX() + SIDE_W + SIDE_GAP;
    }

    private float contW() {
        return PANEL_W - SIDE_PAD - SIDE_W - SIDE_GAP - RIGHT_PAD;
    }

    private float contY() {
        return panelY() + 14.0f;
    }

    private float contH() {
        return PANEL_H - 28.0f;
    }

    private float pillsY() {
        return panelY() + TOP_PAD + 52.0f + 11.0f;
    }

    private float settingsY() {
        return panelY() + PANEL_H - 44.0f;
    }

    private double toPx(double mx) {
        float s = this.lastScale;
        if (s <= 0.01f) {
            return mx;
        }
        double cx = (Interface.mc.getWindow().getScaledWidth() - PANEL_W) * 0.5f + (PANEL_W * 0.5f);
        return ((mx - cx) / s) + cx;
    }

    private double toPy(double my) {
        float s = this.lastScale;
        if (s <= 0.01f) {
            return my;
        }
        double cy = (Interface.mc.getWindow().getScaledHeight() - PANEL_H) * 0.5f + (PANEL_H * 0.5f) + this.lastSlideY;
        return ((my - cy) / s) + cy;
    }

    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        double dA = MathUtil.scale(mouseX, 2);
        double dA2 = MathUtil.scale(mouseY, 2);
        ScaleUtil.a(context, 2);
        ensureLogo();

        for (final GUIPanel gUIPanel : this.c) {
            gUIPanel.a(Delta.getInstance().getModuleProcessor().t().e().stream().filter(obj -> this.a(gUIPanel, obj)).sorted(Comparator.comparing(new Function<Module, String>() {
                @Override
                public String apply(Module obj) {
                    return obj.j();
                }
            }, String.CASE_INSENSITIVE_ORDER)).toList());
        }

        MatrixStack matrices = context.getMatrices();
        float px = panelX();
        float py = panelY();
        float cx = px + (PANEL_W / 2.0f);
        float cy = py + (PANEL_H / 2.0f);
        this.openAnim.a(0.0f, 1.0f, 0.3f, EasingList.i, delta);
        if (this.closing) {
            this.openAnim.a(false);
            this.cascadeAnim.a(0.0f, 12.0f);
            this.viewAnim.a(0.0f, 12.0f);
            for (GUIPanel panel : this.c) {
                panel.a(true);
            }
            if (this.openAnim.a() <= 0.005f && this.cascadeAnim.a() <= 0.01f) {
                ScaleUtil.a(context);
                Interface.mc.setScreen(null);
                return;
            }
        } else {
            this.openAnim.a(true);
            this.cascadeAnim.a(1.0f, 5.5f);
        }
        float open = MathUtil.b(this.openAnim.c(), 0.0f, 1.0f);
        float cascade = this.cascadeAnim.a();
        float sizeScale = ClientSettings.sizeScale();
        float scale = (0.85f + (0.15f * EasingList.s.ease(open))) * sizeScale;
        float slideY = (1.0f - EasingList.j.ease(open)) * 18.0f;
        this.lastScale = scale;
        this.lastSlideY = slideY;
        matrices.push();
        matrices.translate(cx, cy + slideY, 0.0f);
        matrices.scale(scale, scale, 1.0f);
        matrices.translate(-cx, -cy, 0.0f);

        Draw2DProcessor draw = Delta.getInstance().getModuleProcessor().i();
        draw.a(matrices, px, py, PANEL_W, PANEL_H, 12.0f, GUIPanel.scaleAlpha(0xF00A0A10, open));
        drawCrystal(matrices, cx, cy, open);
        renderLogoBox(matrices, draw, cascade);
        int i = 0;
        for (Category category : Category.values()) {
            renderPill(matrices, draw, sideX(), pillsY() + (i * (PILL_H + PILL_GAP)), i, category.a(), category.name(), (i == this.activeCategory) && !this.settingsView, dA, dA2, delta, cascade);
            i++;
        }
        context.fill((int) sideX(), (int) (settingsY() - 7.0f), (int) (sideX() + SIDE_W), (int) (settingsY() - 6.0f), GUIPanel.scaleAlpha(0x26FFFFFF, cascade));
        renderPill(matrices, draw, sideX(), settingsY(), 5, "%", "Settings", this.settingsView, dA, dA2, delta, cascade);

        if (this.ghostPanel != null) {
            this.ghostPanel.a(context, (int) dA, (int) dA2, delta);
            if (this.ghostPanel.b().a() <= 0.02f) {
                this.ghostPanel = null;
            }
        }

        GUIPanel panel = this.c.get(this.activeCategory);
        panel.f().set(contX(), contY(), contW(), contH());
        if (this.settingsView) {
            renderSettings(matrices, draw, context, (int) dA, (int) dA2, delta);
        } else {
            panel.a(context, (int) dA, (int) dA2, delta);
        }
        a(context, cx, py + PANEL_H, (int) dA, (int) dA2, delta, cascade);
        matrices.pop();
        ScaleUtil.a(context);
    }

    private void renderLogoBox(MatrixStack matrices, Draw2DProcessor draw, float cascade) {
        float x = sideX() + 6.0f;
        float y = panelY() + TOP_PAD;
        float enter = EasingList.s.ease(MathUtil.b((cascade - 0.2f) / 0.8f, 0.0f, 1.0f));
        if (enter <= 0.001f) {
            return;
        }
        float s = 0.5f + (0.5f * enter);
        matrices.push();
        matrices.translate(x + 26.0f, y + 26.0f, 0.0f);
        matrices.scale(s, s, 1.0f);
        matrices.translate(-(x + 26.0f), -(y + 26.0f), 0.0f);
        draw.a(matrices, x, y, 52.0f, 52.0f, 10.5f, GUIPanel.fade(0xFF07070B, enter));
        draw.a(matrices, x, y, 52.0f, 52.0f, 10.5f, 1.0f, GUIPanel.scaleAlpha(0x2EFFFFFF, enter));
        if (this.logoLoaded) {
            draw.a(matrices, x + 5.0f, y + 5.0f, 42.0f, 42.0f, 7.0f, GUIPanel.fade(0xFFFFFFFF, enter), 0.0f, 0.0f, 1.0f, 1.0f, this.logoTextureId);
        }
        matrices.pop();
    }

    private void renderPill(MatrixStack matrices, Draw2DProcessor draw, float x, float y, int index, String icon, String label, boolean active, double mouseX, double mouseY, float delta, float cascade) {
        boolean hover = !active && MathUtil.a(mouseX, mouseY, x, y, SIDE_W, PILL_H);
        float hov = this.pillAnim[index].a(hover ? 1.0f : 0.0f, 16.0f);
        float actT = this.pillActive[index].a(active ? 1.0f : 0.0f, 14.0f);
        float enter = EasingList.j.ease(MathUtil.b((cascade - (index * 0.07f)) / 0.6f, 0.0f, 1.0f));
        if (enter <= 0.001f) {
            return;
        }
        float ex = x - ((1.0f - enter) * 14.0f);
        float pw = SIDE_W + (4.0f * actT);
        float cy = y + (PILL_H / 2.0f);
        int base = ColorUtil.lerpColor(0xFF121218, 0xFF1C1C26, hov);
        draw.a(matrices, ex, y, pw, PILL_H, 10.0f, GUIPanel.fade(base, enter));
        if (actT > 0.001f) {
            draw.a(matrices, ex, y, pw, PILL_H, 10.0f,
                    ColorUtil.applyAlphaToColor(0xFF8E2BE8, actT * enter),
                    ColorUtil.applyAlphaToColor(0xFF6E14C4, actT * enter),
                    ColorUtil.applyAlphaToColor(0xFF7C1FD9, actT * enter),
                    ColorUtil.applyAlphaToColor(0xFF5A0DA8, actT * enter));
        }
        int color = GUIPanel.fade(ColorUtil.lerpColor(0xFFD5D5E0, 0xFFFFFFFF, Math.max(hov, actT)), enter);
        Fonts.a.a(matrices, icon, ex + 10.0f, Fonts.a.a(icon, 10.5f, cy), 10.5f, color);
        float maxW = SIDE_W - 30.0f;
        float size = 9.0f;
        float width = Fonts.d.a(label, size);
        if (width > maxW) {
            size *= maxW / width;
        }
        Fonts.d.a(matrices, label, ex + 25.0f, Fonts.d.a(label, size, cy), size, color);
    }

    private void renderSettings(MatrixStack matrices, Draw2DProcessor draw, DrawContext context, int mouseX, int mouseY, float delta) {
        float vr = this.viewAnim.a(1.0f, 14.0f);
        float x = contX();
        float areaY = contY() + 4.0f + ((1.0f - vr) * 8.0f);
        float areaH = contH() - 4.0f;
        Module module = this.selectedModule;
        float content = 32.0f;
        for (Element<?> element : ClientSettings.elements) {
            content += element.getBounds().w() + 4.0f;
        }
        if (module != null) {
            content += 44.0f;
            for (Element<?> element : module.d()) {
                content += (element.getBounds().w() + 4.0f) * element.getVisibilityAnimation().c();
            }
        } else {
            content += 26.0f;
        }
        float scroll = this.settingsScroll.a(Math.min(0.0f, areaH - content), 0.0f, 9.0f);
        ScissorUtil.a(matrices, x, areaY, contW(), areaH);
        float y = areaY + scroll;
        int ei = 0;
        draw.a(matrices, x, y, contW(), 28.0f, 9.0f, GUIPanel.fade(0xF2101017, vr));
        draw.a(matrices, x, y, contW(), 28.0f, 9.0f, 1.0f, GUIPanel.fade(0xFF8300FF, vr));
        Fonts.a.a(matrices, "%", x + 12.0f, Fonts.a.a("%", 10.5f, y + 14.0f), 10.5f, GUIPanel.fade(0xFFD8D8E2, vr));
        Fonts.d.a(matrices, "ClickGUI", x + 28.0f, y + 5.5f, 10.0f, GUIPanel.fade(0xFFFFFFFF, vr));
        y += 32.0f;
        for (Element<?> element : ClientSettings.elements) {
            element.getVisibilityAnimation().a(element.isEnabled());
            element.getVisibilityAnimation().a(0.0f, 1.0f, 0.4f, EasingList.i, delta);
            float vis = element.getVisibilityAnimation().c();
            float st = EasingList.j.ease(MathUtil.b((vr - (ei * 0.05f)) / 0.55f, 0.0f, 1.0f));
            float visible = vis * st * vr;
            if (visible > 0.0f) {
                element.getBounds().set(x + 2.0f, y + ((1.0f - st) * 6.0f), contW() - 4.0f, element.getBounds().w());
                element.render(context, mouseX, mouseY, delta, visible);
                y += (element.getBounds().w() + 4.0f) * vis;
            }
            ei++;
        }
        if (module != null) {
            y += 12.0f;
            draw.a(matrices, x, y, contW(), 28.0f, 9.0f, GUIPanel.fade(0xF2101017, vr));
            draw.a(matrices, x, y, contW(), 28.0f, 9.0f, 1.0f, GUIPanel.fade(0xFF8300FF, vr));
            Fonts.a.a(matrices, module.l().a(), x + 12.0f, Fonts.a.a(module.l().a(), 10.5f, y + 14.0f), 10.5f, GUIPanel.fade(0xFFD8D8E2, vr));
            Fonts.d.a(matrices, module.j(), x + 28.0f, y + 5.5f, 10.0f, GUIPanel.fade(0xFFFFFFFF, vr));
            y += 32.0f;
            for (Element<?> element : module.d()) {
                element.getVisibilityAnimation().a(element.isEnabled());
                element.getVisibilityAnimation().a(0.0f, 1.0f, 0.4f, EasingList.i, delta);
                float vis = element.getVisibilityAnimation().c();
                float st = EasingList.j.ease(MathUtil.b((vr - (ei * 0.05f)) / 0.55f, 0.0f, 1.0f));
                float visible = vis * st * vr;
                if (visible > 0.0f) {
                    element.getBounds().set(x + 2.0f, y + ((1.0f - st) * 6.0f), contW() - 4.0f, element.getBounds().w());
                    element.render(context, mouseX, mouseY, delta, visible);
                    y += (element.getBounds().w() + 4.0f) * vis;
                }
                ei++;
            }
        } else {
            y += 12.0f;
            String hint = "Выбери модуль";
            Fonts.c.a(matrices, hint, x + ((contW() - Fonts.c.a(hint, 8.0f)) / 2.0f), y + 8.0f, 8.0f, GUIPanel.fade(0xFF6A6A78, vr));
        }
        ScissorUtil.a(matrices);
        for (Element<?> element : ClientSettings.elements) {
            element.renderColorPicker(context, mouseX, mouseY, delta);
        }
        if (module != null) {
            for (Element<?> element : module.d()) {
                element.renderColorPicker(context, mouseX, mouseY, delta);
            }
        }
    }

    private void drawCrystal(MatrixStack matrices, float cx, float cy, float open) {
        Draw2DProcessor draw = Delta.getInstance().getModuleProcessor().i();
        float t = ((float) (System.currentTimeMillis() % 20000L)) / 20000.0f;
        float wobble = (float) Math.sin(t * 6.2831855d) * 0.12f;
        float pulse = 1.0f + ((float) Math.sin(t * 12.56637d) * 0.035f);
        matrices.push();
        matrices.translate(cx, cy, 0.0f);
        matrices.scale(pulse, pulse, 1.0f);
        matrices.multiply(new Quaternionf().rotateZ((float) Math.PI / 4.0f + wobble));
        draw.a(matrices, -31.0f, -31.0f, 62.0f, 62.0f, 8.0f, GUIPanel.scaleAlpha(ColorUtil.applyAlphaToColor(0xFF9B5CFF, 0.09f), open));
        draw.a(matrices, -31.0f, -31.0f, 62.0f, 62.0f, 8.0f, 1.0f, GUIPanel.scaleAlpha(ColorUtil.applyAlphaToColor(0xFFFFFFFF, 0.13f), open));
        matrices.push();
        matrices.multiply(new Quaternionf().rotateZ(-(float) Math.PI / 16.0f));
        draw.a(matrices, -17.0f, -17.0f, 34.0f, 34.0f, 5.0f, GUIPanel.scaleAlpha(ColorUtil.applyAlphaToColor(0xFFB985FF, 0.12f), open));
        draw.a(matrices, -17.0f, -17.0f, 34.0f, 34.0f, 5.0f, 1.0f, GUIPanel.scaleAlpha(ColorUtil.applyAlphaToColor(0xFFFFFFFF, 0.10f), open));
        matrices.pop();
        matrices.pop();
    }

    private void ensureLogo() {
        if (this.logoLoaded || Interface.mc.getTextureManager() == null || Interface.mc.getResourceManager() == null) {
            return;
        }
        InputStream stream = null;
        Optional<Resource> optional = Interface.mc.getResourceManager().getResource(LOGO_ID);
        if (optional.isPresent()) {
            try {
                stream = optional.get().getInputStream();
            } catch (Exception e) {
                stream = null;
            }
        }
        if (stream == null) {
            stream = Thread.currentThread().getContextClassLoader().getResourceAsStream("assets/delta/darkvis/logobum.png");
        }
        if (stream == null) {
            if (!this.logoWarned) {
                this.logoWarned = true;
                System.out.println("[Dark Vision] GUIScreen: logobum not found at assets/delta/darkvis/logobum.png");
            }
            return;
        }
        try (InputStream s = stream) {
            NativeImage image = NativeImage.read(s);
            Interface.mc.getTextureManager().registerTexture(LOGO_ID, new NativeImageBackedTexture(image));
            this.logoTextureId = Interface.mc.getTextureManager().getTexture(LOGO_ID).getGlId();
            image.close();
            this.logoLoaded = true;
        } catch (Exception e) {
            if (!this.logoWarned) {
                this.logoWarned = true;
                System.out.println("[Dark Vision] GUIScreen: failed to load logobum: " + e);
            }
        }
    }

    private void selectCategory(int index) {
        GUIPanel target = this.c.get(index);
        boolean fromSettings = this.settingsView;
        boolean samePanel = (index == this.activeCategory) && fromSettings;
        if (!samePanel) {
            GUIPanel prev = this.c.get(this.activeCategory);
            if (prev != target) {
                this.ghostPanel = prev;
                prev.a(true);
            }
        }
        target.a(false);
        target.b().c(0.0f);
        this.activeCategory = index;
        this.settingsView = false;
    }

    public boolean mouseClicked(final double mouseX, final double mouseY, final int button) {
        if (this.closing) {
            return false;
        }
        TextField textField = this.a;
        double dA = this.toPx(MathUtil.scale(mouseX, 2));
        double dA2 = this.toPy(MathUtil.scale(mouseY, 2));
        textField.onMouseClick(dA, dA2, button);
        int i = 0;
        for (Category category : Category.values()) {
            if (MathUtil.a(dA, dA2, sideX(), pillsY() + (i * (PILL_H + PILL_GAP)), SIDE_W, PILL_H)) {
                selectCategory(i);
                return true;
            }
            i++;
        }
        if (MathUtil.a(dA, dA2, sideX(), settingsY(), SIDE_W, PILL_H)) {
            if (!this.settingsView) {
                this.ghostPanel = this.c.get(this.activeCategory);
                this.ghostPanel.a(true);
                this.viewAnim.c(0.0f);
            }
            this.settingsView = true;
            return true;
        }
        GUIPanel panel = this.c.get(this.activeCategory);
        if (this.settingsView) {
            if (ClientSettings.elements.stream().filter(Element::isEnabled).anyMatch(element -> element.onMouseClick(dA, dA2, button))) {
                return true;
            }
            Module module = this.selectedModule;
            if (module != null && module.d().stream().filter(Element::isEnabled).anyMatch(element -> element.onMouseClick(dA, dA2, button))) {
                return true;
            }
        } else if (panel.a(dA, dA2, button)) {
            this.selectedModule = panel.h();
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    public boolean mouseReleased(final double mouseX, final double mouseY, final int button) {
        if (this.closing) {
            return false;
        }
        double dA = this.toPx(MathUtil.scale(mouseX, 2));
        double dA2 = this.toPy(MathUtil.scale(mouseY, 2));
        if (this.settingsView) {
            if (ClientSettings.elements.stream().filter(Element::isEnabled).anyMatch(element -> element.onMouseRelease(dA, dA2, button))) {
                return true;
            }
            Module module = this.selectedModule;
            if (module != null && module.d().stream().filter(Element::isEnabled).anyMatch(element -> element.onMouseRelease(dA, dA2, button))) {
                return true;
            }
        } else {
            GUIPanel panel = this.c.get(this.activeCategory);
            if (panel.b(dA, dA2, button)) {
                return true;
            }
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    public boolean mouseDragged(final double mouseX, final double mouseY, final int button, final double deltaX, final double deltaY) {
        if (this.closing) {
            return false;
        }
        TextField textField = this.a;
        double dA = this.toPx(MathUtil.scale(mouseX, 2));
        double dA2 = this.toPy(MathUtil.scale(mouseY, 2));
        float s = Math.max(0.01f, this.lastScale);
        textField.onMouseDrag(dA, dA2, button);
        if (this.settingsView) {
            if (ClientSettings.elements.stream().filter(Element::isEnabled).anyMatch(element -> element.onMouseDrag(dA, dA2, button, MathUtil.scale(deltaX, 2) / s, MathUtil.scale(deltaY, 2) / s))) {
                return true;
            }
            Module module = this.selectedModule;
            if (module != null && module.d().stream().filter(Element::isEnabled).anyMatch(element -> element.onMouseDrag(dA, dA2, button, MathUtil.scale(deltaX, 2) / s, MathUtil.scale(deltaY, 2) / s))) {
                return true;
            }
        } else {
            GUIPanel panel = this.c.get(this.activeCategory);
            if (panel.a(dA, dA2, button, MathUtil.scale(deltaX, 2) / s, MathUtil.scale(deltaY, 2) / s)) {
                return true;
            }
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    public boolean mouseScrolled(final double mouseX, final double mouseY, double horizontalAmount, final double verticalAmount) {
        if (this.closing) {
            return false;
        }
        double dA = this.toPx(MathUtil.scale(mouseX, 2));
        double dA2 = this.toPy(MathUtil.scale(mouseY, 2));
        if (this.settingsView) {
            if (MathUtil.a(dA, dA2, contX(), contY() + 4.0f, contW(), contH() - 4.0f)) {
                this.settingsScroll.a((float) verticalAmount * 15.0f);
                return true;
            }
        } else {
            GUIPanel panel = this.c.get(this.activeCategory);
            if (panel.a(dA, dA2, verticalAmount)) {
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    public boolean keyPressed(final int keyCode, final int scanCode, final int modifiers) {
        if (this.closing) {
            return true;
        }
        if (keyCode == 256) {
            this.closing = true;
            return true;
        }
        TextField textField = this.a;
        if (keyCode == 70 && (modifiers & 2) != 0) {
            textField.a(!textField.isFocused());
            return true;
        }
        if (textField.isFocused()) {
            textField.a(keyCode, scanCode, modifiers);
            return true;
        }
        if (this.settingsView) {
            if (ClientSettings.elements.stream().filter(Element::isEnabled).anyMatch(element -> element.onKeyPress(keyCode, scanCode, modifiers))) {
                return true;
            }
            Module module = this.selectedModule;
            if (module != null && module.d().stream().filter(Element::isEnabled).anyMatch(element -> element.onKeyPress(keyCode, scanCode, modifiers))) {
                return true;
            }
        } else {
            GUIPanel panel = this.c.get(this.activeCategory);
            if (panel.a(keyCode, scanCode, modifiers)) {
                return true;
            }
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    public boolean charTyped(final char character, final int modifiers) {
        if (this.closing) {
            return false;
        }
        TextField textField = this.a;
        if (textField.isFocused()) {
            textField.a(character, modifiers);
            return true;
        }
        if (this.settingsView) {
            if (ClientSettings.elements.stream().filter(Element::isEnabled).anyMatch(element -> element.onCharTyped(character, modifiers))) {
                return true;
            }
            Module module = this.selectedModule;
            if (module != null && module.d().stream().filter(Element::isEnabled).anyMatch(element -> element.onCharTyped(character, modifiers))) {
                return true;
            }
        } else {
            GUIPanel panel = this.c.get(this.activeCategory);
            if (panel.a(character, modifiers)) {
                return true;
            }
        }
        return super.charTyped(character, modifiers);
    }

    public TextField a() {
        return this.a;
    }

    public AnimationUtil b() {
        return this.b;
    }

    public List<GUIPanel> c() {
        return this.c;
    }

    public String d() {
        return this.d;
    }

    public void close() {
        super.close();
        this.closing = false;
        this.openAnim.c(0.0f);
        this.cascadeAnim.c(0.0f);
        this.viewAnim.c(0.0f);
        this.c.forEach(panel -> panel.a(true));
    }

    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
    }

    public boolean a(GUIPanel panel, Module module) {
        return module.l() == panel.c() && module.j().toLowerCase().contains(this.a.getTextBuffer().toString().toLowerCase());
    }

    private void a(DrawContext context, float centerX, float panelBottom, int mouseX, int mouseY, float delta, float cascade) {
        float enter = EasingList.j.ease(MathUtil.b((cascade - 0.45f) / 0.55f, 0.0f, 1.0f));
        this.a.setSize(new Vector2f(120.0f, 22.0f));
        this.a.setPosition(new Vector2f(centerX - 60.0f, panelBottom + 14.0f + ((1.0f - enter) * 10.0f)));
        this.a.render(context, mouseX, mouseY, delta, enter);
    }
}
