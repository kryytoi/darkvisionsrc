package aethereal.ui.screen;

import aethereal.core.Interface;
import aethereal.setting.BooleanSetting;
import aethereal.setting.SliderSetting;
import aethereal.ui.element.Element;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;

import java.util.ArrayList;
import java.util.List;

public class ClientSettings {
    public static final SliderSetting guiSize = new SliderSetting("Размер ClickGui", 100.0f, 75.0f, 150.0f, 5.0f);
    public static final BooleanSetting openSound = new BooleanSetting("Звук при открытии ClickGui", Boolean.TRUE);
    public static final BooleanSetting toggleSound = new BooleanSetting("Звук включения и выключения функции", Boolean.TRUE);

    public static final List<Element<?>> elements = new ArrayList<>();

    static {
        elements.add(guiSize.createBooleanElement());
        elements.add(openSound.createBooleanElement());
        elements.add(toggleSound.createBooleanElement());
    }

    public static float sizeScale() {
        return guiSize.h() / 100.0f;
    }

    public static void playOpenSound() {
        if (!openSound.h() || Interface.mc.getSoundManager() == null) {
            return;
        }
        Interface.mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.4f));
    }

    public static void playToggleSound(boolean enabled) {
        if (!toggleSound.h() || Interface.mc.getSoundManager() == null) {
            return;
        }
        Interface.mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK.value(), 1.0f, enabled ? 1.25f : 0.75f));
    }
}
