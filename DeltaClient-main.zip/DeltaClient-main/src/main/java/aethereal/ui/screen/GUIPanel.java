package aethereal.ui.screen;

import aethereal.core.Category;
import aethereal.core.Delta;
import aethereal.core.Module;
import aethereal.render.AnimationUtil;
import aethereal.render.ColorUtil;
import aethereal.render.Draw2DProcessor;
import aethereal.render.EasingList;
import aethereal.render.Fonts;
import aethereal.render.ScissorUtil;
import aethereal.ui.element.Element;
import aethereal.util.MathUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Quaternionf;
import org.joml.Vector4f;

import java.util.List;

public class GUIPanel {
    public static final float CARD_H = 38.0f;
    public static final float CARD_GAP = 8.0f;

    private final Vector4f a = new Vector4f(0.0f, 0.0f, 240.0f, 163.0f);
    private final AnimationUtil b = new AnimationUtil();
    private final AnimationUtil c = new AnimationUtil();
    private final AnimationUtil selAnim = new AnimationUtil();
    private final Category d;
    private boolean z;
    private List<Module> e;
    private Module f;
    private Module g;
    private float scroll;
    private float[] relY;
    private float[] drawerH;

    public GUIPanel(Category category) {
        this.d = category;
    }

    public boolean a(final double mouseX, final double mouseY, final int button) {
        if (this.e == null) {
            return false;
        }
        for (Module module : this.e) {
            if (module.n()) {
                module.a(-100 + button);
                module.b(false);
                return true;
            }
        }
        Module hit = moduleAt(mouseX, mouseY);
        if (hit != null) {
            if (inGear(mouseX, mouseY, hit)) {
                hit.c(!hit.o());
                return true;
            }
            if (inToggle(mouseX, mouseY, hit)) {
                hit.a(!hit.m());
                ClientSettings.playToggleSound(hit.m());
                return true;
            }
            if (inDrawer(mouseX, mouseY, hit)) {
                if (button == 1) {
                    hit.c(!hit.o());
                    return true;
                }
            } else {
                if (button == 0) {
                    this.g = (this.g == hit) ? null : hit;
                    return true;
                }
                if (button == 1) {
                    hit.c(!hit.o());
                    return true;
                }
                if (button == 2) {
                    hit.b(true);
                    return true;
                }
            }
        }
        return this.e.stream().filter(Module::o).flatMap(module -> module.d().stream()).filter(Element::isEnabled).anyMatch(element -> element.onMouseClick(mouseX, mouseY, button));
    }

    public boolean b(final double mouseX, final double mouseY, final int button) {
        if (this.e == null) {
            return false;
        }
        return this.e.stream().filter(Module::o).flatMap(module -> module.d().stream()).filter(Element::isEnabled).anyMatch(element -> element.onMouseRelease(mouseX, mouseY, button));
    }

    public boolean a(final double mouseX, final double mouseY, final int button, final double deltaX, final double deltaY) {
        if (this.e == null) {
            return false;
        }
        return this.e.stream().filter(Module::o).flatMap(module -> module.d().stream()).filter(Element::isEnabled).anyMatch(element -> element.onMouseDrag(mouseX, mouseY, button, deltaX, deltaY));
    }

    public boolean a(final int keyCode, final int scanCode, final int modifiers) {
        if (this.e == null) {
            return false;
        }
        for (Module module : this.e) {
            if (module.n()) {
                module.a(keyCode);
                module.b(false);
                return true;
            }
        }
        return this.e.stream().filter(Module::o).flatMap(module -> module.d().stream()).filter(Element::isEnabled).anyMatch(element -> element.onKeyPress(keyCode, scanCode, modifiers));
    }

    public boolean a(final char chr, final int modifiers) {
        if (this.e == null) {
            return false;
        }
        return this.e.stream().filter(Module::o).flatMap(module -> module.d().stream()).filter(Element::isEnabled).anyMatch(element -> element.onCharTyped(chr, modifiers));
    }

    public boolean a(final double mouseX, final double mouseY, final double amount) {
        if (this.e == null || !MathUtil.a(mouseX, mouseY, this.a.x, this.a.y, this.a.z, this.a.w)) {
            return false;
        }
        if (this.e.stream().filter(Module::o).flatMap(module -> module.d().stream()).filter(Element::isEnabled).anyMatch(element -> element.onMouseScroll(mouseX, mouseY, amount))) {
            return true;
        }
        this.b.a((float) amount * 15.0f);
        return true;
    }

    public void a(List<Module> modules) {
        this.e = modules;
    }

    public void a(Module hovered) {
        this.f = hovered;
    }

    public void a(boolean dismiss) {
        this.z = dismiss;
    }

    public Vector4f f() {
        return this.a;
    }

    public AnimationUtil a() {
        return this.b;
    }

    public AnimationUtil b() {
        return this.c;
    }

    public Category c() {
        return this.d;
    }

    public List<Module> d() {
        return this.e;
    }

    public Module e() {
        return this.f;
    }

    public Module h() {
        return this.g;
    }

    static int fade(int color, float amount) {
        float clamped = MathUtil.b(amount, 0.0f, 1.0f);
        if (clamped >= 0.999f) {
            return color;
        }
        return (color & 0x00FFFFFF) | ((int) (255.0f * clamped) << 24);
    }

    static int scaleAlpha(int color, float amount) {
        float clamped = MathUtil.b(amount, 0.0f, 1.0f);
        if (clamped >= 0.999f) {
            return color;
        }
        int alpha = (color >>> 24) & 0xFF;
        return (color & 0x00FFFFFF) | ((int) (alpha * clamped) << 24);
    }

    private float drawerFull(Module module) {
        if (module.d().isEmpty()) {
            return 0.0f;
        }
        float h = 10.0f;
        for (Element<?> element : module.d()) {
            h += element.getBounds().w() + 4.0f;
        }
        return h - 4.0f + 6.0f;
    }

    private void computeLayout() {
        if (this.e == null) {
            return;
        }
        int n = this.e.size();
        if (this.relY == null || this.relY.length != n) {
            this.relY = new float[n];
            this.drawerH = new float[n];
        }
        float y = 0.0f;
        for (int i = 0; i < n; i++) {
            Module module = this.e.get(i);
            this.relY[i] = y;
            this.drawerH[i] = drawerFull(module) * module.i().c();
            y += CARD_H + 2.0f + this.drawerH[i] + CARD_GAP;
        }
    }

    private float totalContent() {
        if (this.e == null || this.e.isEmpty()) {
            return 0.0f;
        }
        int n = this.e.size();
        float total = 0.0f;
        for (int i = 0; i < n; i++) {
            total += CARD_H + 2.0f + this.drawerH[i];
            if (i < n - 1) {
                total += CARD_GAP;
            }
        }
        return total;
    }

    private Module moduleAt(double mouseX, double mouseY) {
        if (this.e == null || !MathUtil.a(mouseX, mouseY, this.a.x, this.a.y, this.a.z, this.a.w)) {
            return null;
        }
        computeLayout();
        float y0 = this.a.y + this.scroll;
        for (int i = 0; i < this.e.size(); i++) {
            float y = y0 + this.relY[i];
            if (MathUtil.a(mouseX, mouseY, this.a.x, y, this.a.z, CARD_H + 2.0f + this.drawerH[i])) {
                return this.e.get(i);
            }
        }
        return null;
    }

    private boolean inToggle(double mouseX, double mouseY, Module module) {
        if (this.e == null) {
            return false;
        }
        computeLayout();
        for (int i = 0; i < this.e.size(); i++) {
            if (this.e.get(i) == module) {
                float y = this.a.y + this.scroll + this.relY[i];
                return MathUtil.a(mouseX, mouseY, this.a.x + this.a.z - 39.0f, y + 13.0f, 24.0f, 12.0f);
            }
        }
        return false;
    }

    private boolean inGear(double mouseX, double mouseY, Module module) {
        if (this.e == null) {
            return false;
        }
        computeLayout();
        for (int i = 0; i < this.e.size(); i++) {
            if (this.e.get(i) == module) {
                float y = this.a.y + this.scroll + this.relY[i];
                return MathUtil.a(mouseX, mouseY, this.a.x + this.a.z - 61.0f, y + (CARD_H / 2.0f) - 7.0f, 14.0f, 14.0f);
            }
        }
        return false;
    }

    private boolean inDrawer(double mouseX, double mouseY, Module module) {
        if (this.e == null) {
            return false;
        }
        computeLayout();
        for (int i = 0; i < this.e.size(); i++) {
            if (this.e.get(i) == module) {
                float dh = this.drawerH[i];
                if (dh <= 0.0f) {
                    return false;
                }
                float y = this.a.y + this.scroll + this.relY[i] + CARD_H + 2.0f;
                return MathUtil.a(mouseX, mouseY, this.a.x, y, this.a.z, dh);
            }
        }
        return false;
    }

    public void a(DrawContext context, int mouseX, int mouseY, float delta) {
        if (this.e == null) {
            return;
        }
        MatrixStack matrices = context.getMatrices();
        Draw2DProcessor draw = Delta.getInstance().getModuleProcessor().i();
        float reveal = this.c.a(this.z ? 0.0f : 1.0f, this.z ? 12.0f : 14.0f);
        float selT = this.selAnim.a(this.g != null ? 1.0f : 0.0f, 16.0f);
        this.f = null;
        computeLayout();
        float total = totalContent();
        this.scroll = this.b.a(Math.min(0.0f, this.a.w - total), 0.0f, 9.0f);
        float y0 = this.a.y + this.scroll;
        float bottom = this.a.y + this.a.w;
        int n = this.e.size();
        ScissorUtil.a(matrices, this.a.x, this.a.y, this.a.z, this.a.w);
        for (int i = 0; i < n; i++) {
            Module module = this.e.get(i);
            float y = y0 + this.relY[i];
            boolean hoverHit = MathUtil.a((double) mouseX, (double) mouseY, this.a.x, y, this.a.z, CARD_H + 2.0f + this.drawerH[i]);
            module.g().a(0.0f, 1.0f, 0.6f, EasingList.i, delta);
            module.g().a(hoverHit);
            module.f().a(0.0f, 1.0f, 0.4f, EasingList.i, delta);
            module.f().a(module.m());
            module.i().a(0.0f, 1.0f, 0.35f, EasingList.i, delta);
            module.i().a(module.o());
            module.h().a(0.0f, 1.0f, 0.4f, EasingList.i, delta);
            module.h().a(module.n());
            if (hoverHit) {
                this.f = module;
            }
            float maxI = Math.max(1, n - 1);
            float delay = (i / (float) maxI) * 0.4f;
            float r = MathUtil.b((reveal - delay) / 0.55f, 0.0f, 1.0f);
            float revealI = EasingList.j.ease(r);
            if (revealI <= 0.01f) {
                continue;
            }
            float cy = y + ((1.0f - revealI) * 12.0f);
            if (cy + CARD_H + this.drawerH[i] > this.a.y && cy < bottom) {
                float hoverT = module.g().c();
                matrices.push();
                float hs = 1.0f + (0.018f * hoverT);
                if (hs > 1.0001f) {
                    matrices.translate(this.a.x + (this.a.z * 0.5f), cy + (CARD_H * 0.5f), 0.0f);
                    matrices.scale(hs, hs, 1.0f);
                    matrices.translate(-(this.a.x + (this.a.z * 0.5f)), -(cy + (CARD_H * 0.5f)), 0.0f);
                }
                renderCard(matrices, draw, module, this.a.x, cy, this.a.z, hoverT, module == this.g, selT, revealI);
                matrices.pop();
                renderDrawer(matrices, draw, context, module, this.a.x, cy, this.a.z, mouseX, mouseY, delta, revealI);
            }
        }
        ScissorUtil.a(matrices);
        for (Module module : this.e) {
            if (module.o()) {
                for (Element<?> element : module.d()) {
                    element.renderColorPicker(context, (double) mouseX, (double) mouseY, delta);
                }
            }
        }
    }

    private void renderCard(MatrixStack matrices, Draw2DProcessor draw, Module module, float x, float y, float w, float hover, boolean selected, float selT, float reveal) {
        int bg = ColorUtil.lerpColor(0xF2101017, 0xF21A1230, hover);
        draw.a(matrices, x, y, w, CARD_H, 10.0f, fade(bg, reveal));
        float strokeA = selected ? selT : hover * 0.55f;
        if (strokeA > 0.01f) {
            draw.a(matrices, x, y, w, CARD_H, 10.0f, 1.0f, fade(0xFF8300FF, reveal * Math.min(1.0f, strokeA)));
        }
        Fonts.d.a(matrices, module.j(), x + 12.0f, y + 5.5f, 10.0f, fade(0xFFFFFFFF, reveal));
        String desc = module.k();
        if (desc != null && !desc.isEmpty()) {
            float dSize = 6.5f;
            float dMaxW = w - 76.0f;
            float dw = Fonts.c.a(desc, dSize);
            if (dw > dMaxW) {
                dSize = Math.max(4.5f, (dSize * dMaxW) / dw);
            }
            Fonts.c.a(matrices, desc, x + 12.0f, y + 21.5f, dSize, fade(0xFF8A8A98, reveal));
        }
        if (!module.d().isEmpty()) {
            float ext = module.i().c();
            if (ext > 0.001f) {
                matrices.push();
                matrices.translate(x + w - 54.0f, y + (CARD_H / 2.0f), 0.0f);
                matrices.multiply(new Quaternionf().rotateZ(-ext * ((float) Math.PI * 0.5f)));
                matrices.translate(-(x + w - 54.0f), -(y + (CARD_H / 2.0f)), 0.0f);
            }
            Fonts.a.a(matrices, "%", x + w - 54.0f, Fonts.a.a("%", 9.5f, y + (CARD_H / 2.0f)), 9.5f, fade(0xFFD8D8E2, reveal));
            if (ext > 0.001f) {
                matrices.pop();
            }
        }
        float act = module.f().c();
        float knobT = EasingList.s.ease(MathUtil.b(act, 0.0f, 1.0f));
        float tgX = x + w - 39.0f;
        float tgY = y + 13.0f;
        draw.a(matrices, tgX, tgY, 24.0f, 12.0f, 6.0f, fade(ColorUtil.lerpColor(0xFF2B2B35, 0xFF7C18D9, act), reveal));
        draw.a(matrices, tgX + 2.0f + (11.5f * knobT), tgY + 1.75f, 8.5f, 8.5f, 4.25f, fade(0xFFFFFFFF, reveal));
    }

    private void renderDrawer(MatrixStack matrices, Draw2DProcessor draw, DrawContext context, Module module, float x, float cardY, float w, int mouseX, int mouseY, float delta, float reveal) {
        float ext = module.i().c();
        if (ext <= 0.01f || module.d().isEmpty()) {
            return;
        }
        float full = drawerFull(module);
        float dh = full * ext;
        float dy = cardY + CARD_H + 2.0f;
        draw.a(matrices, x + 3.0f, dy, w - 6.0f, dh, 9.0f, fade(0xF20C0C13, reveal * ext));
        ScissorUtil.a(matrices, x + 3.0f, dy, w - 6.0f, dh);
        float ey = dy + 6.0f;
        int ei = 0;
        for (Element<?> element : module.d()) {
            element.getVisibilityAnimation().a(element.isEnabled());
            element.getVisibilityAnimation().a(0.0f, 1.0f, 0.4f, EasingList.i, delta);
            float vis = element.getVisibilityAnimation().c();
            float st = MathUtil.b((ext - (ei * 0.08f)) * 2.2f, 0.0f, 1.0f);
            if (vis > 0.01f && st > 0.01f) {
                element.getBounds().set(x + 8.0f, ey + ((1.0f - st) * 5.0f), w - 16.0f, element.getBounds().w());
                element.render(context, (double) mouseX, (double) mouseY, delta, vis * st);
                ey += (element.getBounds().w() + 4.0f) * vis;
            }
            ei++;
        }
        ScissorUtil.a(matrices);
    }

    public void a(DrawContext context, double mouseX, double mouseY, float delta) {
        if (this.e == null) {
            return;
        }
        for (Module module : this.e) {
            for (Element<?> element : module.d()) {
                element.renderColorPicker(context, mouseX, mouseY, delta);
            }
        }
    }
}
