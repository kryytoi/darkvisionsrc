package aethereal.ui.theme;

import aethereal.core.Delta;
import aethereal.core.Interface;
import aethereal.render.Draw2DProcessor;
import aethereal.render.Fonts;
import aethereal.ui.screen.MainScreen;
import aethereal.ui.shader.GradientUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.gui.screen.multiplayer.AddServerScreen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.screen.multiplayer.DirectConnectScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.world.CreateWorldScreen;
import net.minecraft.client.gui.screen.world.CustomizeBuffetLevelScreen;
import net.minecraft.client.gui.screen.world.CustomizeFlatLevelScreen;
import net.minecraft.client.gui.screen.world.EditWorldScreen;
import net.minecraft.client.gui.screen.world.ExperimentsScreen;
import net.minecraft.client.gui.screen.world.PresetsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.world.level.storage.LevelSummary;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class DarkVisionUI {
    public static final int ACCENT = 0xFF8300FF;
    public static final int PANEL = 0xF208080E;
    public static final int PANEL_BORDER = 0x598300FF;
    public static final int ROW_SELECTED = 0xF231105A;
    public static final int ROW_HOVER = 0xF2141422;
    public static final int BTN_BG = 0xFF0B0B0D;
    public static final int BTN_HOVER = 0xFF171020;
    public static final int BTN_DISABLED = 0xFF0A0A0C;
    public static final int TEXT_SOFT = 0xFFD0D0D8;
    public static final int TEXT_DIM = 0xFF8A8A9A;
    public static final int TEXT_MUTED = 0xFF6A6A75;

    public static boolean a() {
        return a(Interface.mc.currentScreen);
    }

    public static boolean a(Screen screen) {
        if ((screen instanceof SelectWorldScreen) || (screen instanceof CreateWorldScreen)
                || (screen instanceof MultiplayerScreen) || (screen instanceof ConnectScreen)
                || (screen instanceof DirectConnectScreen) || (screen instanceof AddServerScreen)
                || (screen instanceof EditWorldScreen) || (screen instanceof PresetsScreen)
                || (screen instanceof ExperimentsScreen) || (screen instanceof CustomizeFlatLevelScreen)
                || (screen instanceof CustomizeBuffetLevelScreen)) {
            if (!dvLogged) {
                dvLogged = true;
                System.out.println("[Dark Vision] Dark Vision UI активен: " + screen.getClass().getSimpleName());
            }
            return true;
        }
        return false;
    }

    private static boolean dvLogged = false;

    private static final Map<String, Identifier> ICON_CACHE = new HashMap<>();
    private static boolean iconsLogDone = false;

    public static Identifier serverIconId(ServerInfo server) {
        byte[] favicon = server.getFavicon();
        if (favicon == null || favicon.length == 0) {
            return null;
        }
        String key = "srv" + Arrays.hashCode(favicon);
        Identifier cached = ICON_CACHE.get(key);
        if (cached != null) {
            return cached;
        }
        try {
            return registerIcon(key, NativeImage.read(favicon));
        } catch (Throwable t) {
            return null;
        }
    }

    public static Identifier worldIconId(LevelSummary level) {
        Path path = level.getIconPath();
        if (path == null || !Files.isRegularFile(path)) {
            return null;
        }
        String key = "wld" + path.hashCode();
        Identifier cached = ICON_CACHE.get(key);
        if (cached != null) {
            return cached;
        }
        try (InputStream stream = Files.newInputStream(path)) {
            return registerIcon(key, NativeImage.read(stream));
        } catch (Throwable t) {
            return null;
        }
    }

    private static Identifier registerIcon(String key, NativeImage image) {
        if (image == null) {
            return null;
        }
        Identifier id = Identifier.of("delta", "dvicon_" + key);
        Interface.mc.getTextureManager().registerTexture(id, new NativeImageBackedTexture(image));
        ICON_CACHE.put(key, id);
        return id;
    }

    public static void drawIcon(DrawContext context, int x, int y, Identifier texId, boolean server) {
        if (!iconsLogDone) {
            iconsLogDone = true;
            System.out.println("[Dark Vision] Icons v2: активен (иконки серверов/миров)");
        }
        if (texId != null) {
            context.drawTexture((id) -> RenderLayer.getGui(), texId, x, y, 0.0f, 0.0f, 32, 32, 32, 32);
            return;
        }
        MatrixStack matrices = context.getMatrices();
        Draw2DProcessor draw = Delta.getInstance().getModuleProcessor().i();
        draw.a(matrices, x, y, 32.0f, 32.0f, 7.0f, 0xFF161022);
        draw.a(matrices, x, y, 32.0f, 32.0f, 7.0f, 1.0f, 0x598300FF);
        String glyph = server ? "C" : "@";
        Fonts.a.a(matrices, glyph, (x + 16.0f), Fonts.a.a(glyph, 13.0f, (y + 16.0f)), 13.0f, ACCENT);
    }

    public static void a(DrawContext context, int width, int height, int mouseX, int mouseY) {
        MainScreen.a(context, width, height, mouseX, mouseY, 1.0f);
    }

    public static void a(DrawContext context, String label) {
        MatrixStack matrices = context.getMatrices();
        Draw2DProcessor draw = Delta.getInstance().getModuleProcessor().i();
        float badgeW = Math.max(Fonts.e.a("Dark Vision", 11.5f), Fonts.e.a(label, 7.5f)) + 24.0f;
        draw.a(matrices, 4.0f, 4.0f, badgeW, 24.0f, 4.0f, 0xE606060B);
        draw.a(matrices, 4.0f, 4.0f, badgeW, 24.0f, 4.0f, 1.0f, PANEL_BORDER);
        context.fill(9, 9, 11, 23, ACCENT);
        Fonts.e.a(matrices, GradientUtil.a("Dark Vision", ACCENT, 5.0f, 0.5f), 15.0f, 6.5f, 11.5f);
        Fonts.e.a(matrices, label, 15.0f, 18.0f, 7.5f, TEXT_DIM);
    }

    public static void a(DrawContext context, ButtonWidget button, int mouseX, int mouseY) {
        int x = button.getX();
        int y = button.getY();
        int w = button.getWidth();
        int h = button.getHeight();
        boolean hovered = button.active && button.isMouseOver(mouseX, mouseY);
        MatrixStack matrices = context.getMatrices();
        Draw2DProcessor draw = Delta.getInstance().getModuleProcessor().i();
        if (hovered) {
            draw.a(matrices, x, y, w, h, 5.0f, 1.0f, ACCENT);
        }
        int bg = !button.active ? BTN_DISABLED : (hovered ? BTN_HOVER : BTN_BG);
        draw.b(matrices, x, y, w, h, 5.0f, bg, 1.0f);
        String message = (button.getMessage() == null) ? "" : button.getMessage().getString();
        if (!message.isEmpty()) {
            float size = 8.0f;
            float tx = x + ((w - Fonts.e.a(message, size)) / 2.0f);
            float ty = y + ((h - 9.0f) / 2.0f);
            if (hovered) {
                float time = (System.currentTimeMillis() % 3000L) / 3000.0f;
                MutableText text = Text.literal("");
                for (int i = 0; i < message.length(); i++) {
                    float wave = (float) ((Math.sin(((double) (time + ((i * 0.5f) / message.length()))) * 6.2831855d) * 0.5d) + 0.5d);
                    int c = (int) (185.0f + (70.0f * wave));
                    text.append(Text.literal(String.valueOf(message.charAt(i))).setStyle(Style.EMPTY.withColor((c << 16) | (c << 8) | c)));
                }
                Fonts.e.a(matrices, text, tx, ty, size);
            } else {
                Fonts.e.a(matrices, message, tx, ty, size, button.active ? TEXT_SOFT : TEXT_MUTED);
            }
        }
    }

    public static void a(DrawContext context, int x, int y, int w, int h, boolean selected, boolean hovered) {
        if (!selected && !hovered) {
            return;
        }
        MatrixStack matrices = context.getMatrices();
        Draw2DProcessor draw = Delta.getInstance().getModuleProcessor().i();
        if (selected) {
            draw.a(matrices, (x + 1), (y + 1), (w - 2.0f), (h - 2.0f), 5.0f, ROW_SELECTED);
            context.fill(x + 3, y + 4, x + 5, y + h - 4, ACCENT);
        } else {
            draw.a(matrices, (x + 1), (y + 1), (w - 2.0f), (h - 2.0f), 5.0f, ROW_HOVER);
        }
    }

    public static String a(long epochMillis) {
        return LocalDateTime.ofInstant(Instant.ofEpochMilli(epochMillis), ZoneId.systemDefault())
                .format(DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm"));
    }
}
