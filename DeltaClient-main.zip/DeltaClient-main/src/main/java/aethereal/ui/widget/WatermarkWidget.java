package aethereal.ui.widget;

import aethereal.core.Delta;
import aethereal.core.Interface;
import aethereal.event.DrawEvent;
import aethereal.render.ColorUtil;
import aethereal.render.EasingList;
import aethereal.render.Fonts;
import aethereal.setting.BooleanSetting;
import aethereal.ui.element.DragInfo;
import aethereal.util.MathUtil;
import aethereal.util.ServerUtil;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.resource.Resource;
import net.minecraft.util.Identifier;

import java.io.InputStream;
import java.util.Optional;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class WatermarkWidget extends Widget implements Interface {
    private final BooleanSetting g;
    private final BooleanSetting h;
    private final BooleanSetting i;
    private final BooleanSetting j;
    private final BooleanSetting k;
    private final BooleanSetting l;
    private final BooleanSetting m;
    private final BooleanSetting n;
    private final BooleanSetting o;
    private float f;

    private static final Identifier LOGO_ID = Identifier.of("delta", "darkvis/logo");
    private static final int PILL_COLOR = 0xFF000000;
    private static final int TEXT_COLOR = 0xFFFFFFFF;
    private static final int ACCENT_COLOR = 0xFF8300FF;

    private static final float ROW_GAP = 5.0f;
    private static final float PILL_GAP = 6.0f;
    private static final float PADDING = 4.0f;
    private static final float LOGO_PAD = 4.5f;
    private static final float LOGO_SIZE = 10.5f;
    private static final float SEP_GAP = 5.0f;
    private static final float LOGO_ASPECT = 30.0f / 19.0f;

    private boolean logoLoaded = false;
    private boolean logoWarned = false;
    private int logoTextureId = -1;
    private int logoWidth;
    private int logoHeight;

    public WatermarkWidget() {
        super(new DragInfo("Инфо-панель", 0.0f, 0.0f, 0.0f, 0.0f));
        this.g = new BooleanSetting("Боковое отображение", true);
        this.h = new BooleanSetting("Разделять элементы", false);
        this.i = new BooleanSetting("Частота кадров", true);
        this.j = new BooleanSetting("Задержка игрока", true);
        this.k = new BooleanSetting("Текущее время", true);
        this.l = new BooleanSetting("Логин в клиенте", false);
        this.m = new BooleanSetting("Координаты", true);
        this.n = new BooleanSetting("Задержка сервера", false);
        this.o = new BooleanSetting("Скорость игрока", false);
        j().setWidget(this);
        j().setDragStatus(2);
        a(this.g, this.h, this.i, this.j, this.k, this.l, this.m, this.n, this.o);
    }

    @Override
    public void a(DrawEvent event) {
        d().a(true);
        d().a(0.0f, 1.0f, 0.3f, EasingList.g, event.g());
        this.f = MathUtil.c(this.f, mc.getCurrentFps(), 0.1f);
        ensureLogo();

        List<String> topSections = k();
        List<String> bottomSections = l();

        float rowH = this.d;
        float radius = rowH / 2.0f;
        float logoW = (this.logoLoaded && this.logoHeight > 0)
                ? LOGO_SIZE * this.logoWidth / (float) this.logoHeight
                : LOGO_SIZE * LOGO_ASPECT;
        float logoPillW = logoW + (LOGO_PAD * 2.0f);
        float topPillW = rowWidth(topSections);
        float bottomPillW = rowWidth(bottomSections);
        float topW = logoPillW + (topSections.isEmpty() ? 0.0f : PILL_GAP + topPillW);

        float x = this.g.c() ? 5.0f : (mc.getWindow().getScaledWidth() - topW) / 2.0f;
        float y = 5.0f + bossBarOffset();
        float bottomX = this.g.c() ? x : x + ((topW - bottomPillW) / 2.0f);
        float totalH = bottomSections.isEmpty() ? rowH : (rowH * 2.0f) + ROW_GAP;

        j().setX(x);
        j().setY(y);
        j().setWidth(topW);
        j().setHeight(totalH);

        float anim = a();
        if (anim > 0.0f) {
            pill(event, x, y, logoPillW, rowH, radius, anim);
            drawLogo(event, x, y, logoPillW, rowH, logoW, anim);
            if (!topSections.isEmpty()) {
                row(event, x + logoPillW + PILL_GAP, y, topSections, rowH, radius, anim);
            }
            if (!bottomSections.isEmpty()) {
                row(event, bottomX, y + rowH + ROW_GAP, bottomSections, rowH, radius, anim);
            }
        }
        super.a(event);
    }

    private void pill(DrawEvent event, float x, float y, float width, float height, float radius, float anim) {
        event.getDraw2DProcessor().a(event.h(), x, y, width, height, radius, ColorUtil.applyAlphaToColor(PILL_COLOR, anim));
    }

    private void drawLogo(DrawEvent event, float pillX, float pillY, float pillW, float rowH, float logoW, float anim) {
        float logoH = LOGO_SIZE;
        float lx = pillX + ((pillW - logoW) / 2.0f);
        float ly = pillY + ((rowH - logoH) / 2.0f);
        if (this.logoLoaded) {
            event.getDraw2DProcessor().a(event.h(), lx, ly, logoW, logoH, 0.0f,
                    ColorUtil.applyAlphaToColor(0xFFFFFFFF, anim), 0.0f, 0.0f, 1.0f, 1.0f, this.logoTextureId);
        } else {
            float size = logoH - 0.5f;
            Fonts.a.a(event.h(), "a", lx + ((logoW - Fonts.a.a("a", size)) / 2.0f),
                    pillY + ((rowH - Fonts.a.a(size)) / 2.0f), size, ColorUtil.applyAlphaToColor(ACCENT_COLOR, anim));
        }
    }

    private void row(DrawEvent event, float x, float y, List<String> sections, float rowH, float radius, float anim) {
        if (this.h.c()) {
            float cursor = x;
            for (int i = 0; i < sections.size(); i++) {
                String text = sections.get(i);
                float width = (PADDING * 2.0f) + Fonts.e.a(text, this.e);
                pill(event, cursor, y, width, rowH, radius, anim);
                text(event, text, cursor + PADDING, y, rowH, TEXT_COLOR, anim);
                cursor += width + PILL_GAP;
            }
            return;
        }
        pill(event, x, y, rowWidth(sections), rowH, radius, anim);
        float cursor = x + PADDING;
        for (int i = 0; i < sections.size(); i++) {
            if (i > 0) {
                cursor += SEP_GAP;
                text(event, "/", cursor, y, rowH, ACCENT_COLOR, anim);
                cursor += Fonts.e.a("/", this.e) + SEP_GAP;
            }
            text(event, sections.get(i), cursor, y, rowH, TEXT_COLOR, anim);
            cursor += Fonts.e.a(sections.get(i), this.e);
        }
    }

    private void text(DrawEvent event, String text, float x, float y, float rowH, int color, float anim) {
        float textY = y + ((rowH - Fonts.e.a(this.e)) / 2.0f) - 0.5f;
        Fonts.e.a(event.h(), text, x, textY, this.e, ColorUtil.applyAlphaToColor(color, anim));
    }

    private float rowWidth(List<String> sections) {
        if (sections.isEmpty()) {
            return 0.0f;
        }
        if (this.h.c()) {
            float width = 0.0f;
            for (String section : sections) {
                width += (PADDING * 2.0f) + Fonts.e.a(section, this.e);
            }
            return width + (PILL_GAP * (sections.size() - 1));
        }
        float width = PADDING * 2.0f;
        float slashWidth = Fonts.e.a("/", this.e);
        for (int i = 0; i < sections.size(); i++) {
            if (i > 0) {
                width += (SEP_GAP * 2.0f) + slashWidth;
            }
            width += Fonts.e.a(sections.get(i), this.e);
        }
        return width;
    }

    private float bossBarOffset() {
        if (this.g.c() || ((platform.inject.accessors.BossBarHudAccessor) mc.inGameHud.getBossBarHud()).getBossBars().isEmpty()) {
            return 0.0f;
        }
        int size = ((platform.inject.accessors.BossBarHudAccessor) mc.inGameHud.getBossBarHud()).getBossBars().size() - 1;
        Objects.requireNonNull(mc.textRenderer);
        return (((12 + (size * (10 + 9))) + 5) * mc.getWindow().calculateScaleFactor(mc.options.getGuiScale().getValue().intValue(), mc.forcesUnicodeFont()))
                / mc.getWindow().calculateScaleFactor(2, mc.forcesUnicodeFont());
    }

    private void ensureLogo() {
        if (this.logoLoaded || mc.getTextureManager() == null || mc.getResourceManager() == null) {
            return;
        }
        InputStream stream = null;
        String source = null;
        Optional<Resource> optional = mc.getResourceManager().getResource(LOGO_ID);
        if (optional.isPresent()) {
            try {
                stream = optional.get().getInputStream();
                source = "resource pack [" + optional.get().getPackId() + "]";
            } catch (Exception e) {
                stream = null;
            }
        }
        if (stream == null) {
            stream = Thread.currentThread().getContextClassLoader().getResourceAsStream("assets/delta/darkvis/logo.png");
            if (stream != null) {
                source = "classpath (dev resources)";
            }
        }
        if (stream == null) {
            if (!this.logoWarned) {
                this.logoWarned = true;
                System.out.println("[Dark Vision] WatermarkWidget: logo not found at assets/delta/darkvis/logo.png - displaying placeholder icon");
            }
            return;
        }
        try (InputStream s = stream) {
            NativeImage image = NativeImage.read(s);
            mc.getTextureManager().registerTexture(LOGO_ID, new NativeImageBackedTexture(image));
            this.logoTextureId = mc.getTextureManager().getTexture(LOGO_ID).getGlId();
            this.logoWidth = image.getWidth();
            this.logoHeight = image.getHeight();
            image.close();
            this.logoLoaded = true;
            if (!this.logoWarned) {
                this.logoWarned = true;
                System.out.println("[Dark Vision] WatermarkWidget: logo loaded " + this.logoWidth + "x" + this.logoHeight
                        + " from " + source);
            }
        } catch (Exception e) {
            if (!this.logoWarned) {
                this.logoWarned = true;
                System.out.println("[Dark Vision] WatermarkWidget: failed to load logo (" + source + "): " + e);
            }
        }
    }

    private List<String> k() {
        List<String> sections = new ArrayList<>();
        if (this.l.c()) {
            sections.add(Delta.getInstance().g().username());
        }
        if (this.i.c()) {
            sections.add(((int) this.f) + " fps");
        }
        if (this.j.c()) {
            sections.add(ServerUtil.d() + " ping");
        }
        if (this.k.c()) {
            sections.add(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")));
        }
        return sections;
    }

    private List<String> l() {
        List<String> sections = new ArrayList<>();
        if (this.m.c() && mc.player != null) {
            sections.add("X " + ((int) mc.player.getX()));
            sections.add("Y " + ((int) mc.player.getY()));
            sections.add("Z " + ((int) mc.player.getZ()));
        }
        if (this.n.c()) {
            sections.add(String.format("%.1f TPS", Delta.getInstance().getModuleProcessor().v().getTPSHandler().a()));
        }
        if (this.o.c() && mc.player != null) {
            sections.add(String.format("%.2f BPS", ServerUtil.c()));
        }
        return sections;
    }
}
