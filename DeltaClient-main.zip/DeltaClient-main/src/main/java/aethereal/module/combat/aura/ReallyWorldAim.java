package aethereal.module.combat.aura;

import aethereal.core.Delta;
import aethereal.core.Interface;
import aethereal.module.combat.AuraUtil;
import aethereal.util.Rotation;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.security.SecureRandom;

/**
 * Тип наведения "Really World".
 * Логика: плавное лерп-приближение точки прицеливания и якоря глаз,
 * осциллирующий yaw-сдвиг (cos с периодом ~60 мс), дополнительный шум
 * по snapTicks, случайные step-скорости по тикам и 4 разных
 * распределения случайных чисел (biased / gaussian / math / secure).
 */
public class ReallyWorldAim implements Interface {
    private ReallyWorldAim() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    // --- осцилляция / шум ---
    private static final float YAW_RANGE_MIN = 15.0f;
    private static final float YAW_RANGE_MAX = 17.0f;
    private static final double OSCILLATION_PERIOD = 60.0d;
    private static final float SNAP_TICKS_LOW = 5.0f;
    private static final float SNAP_TICKS_HIGH = 9.0f;
    private static final float SNAP_TICKS_MAX = 14.0f;
    private static final float SNAP_OFFSET_VALUE = -1.0f;
    private static final double BASE_YAW_OFFSET = 90.0d;
    private static final float TICK_MOD_EVEN = 4.0f;
    private static final float YAW_OFFSET_A = 9.0f;
    private static final float YAW_OFFSET_B = 11.0f;
    private static final float YAW_OFFSET_C = 10.0f;
    private static final float YAW_OFFSET_D = 13.0f;
    private static final float TICK_MOD_ODD_1 = 6.0f;
    private static final float TICK_MOD_ODD_2 = 8.0f;
    private static final float YAW_OFFSET_E = 17.0f;
    private static final float YAW_OFFSET_F = 19.0f;
    private static final float YAW_OFFSET_G = 6.0f;
    private static final float YAW_OFFSET_H = 7.0f;
    private static final boolean INVERT_OSCILLATION = false;

    // --- лерп-сглаживание ---
    private static final float LERP_ALPHA_INTERSECT_A = 0.9f;
    private static final float LERP_ALPHA_INTERSECT_B = 0.7f;
    private static final float LERP_ALPHA_INTERSECT_C = 0.98f;
    private static final float LERP_ALPHA_INTERSECT_D = 0.91f;
    private static final float LERP_SPEED_INTERSECT_X1 = 0.35f;
    private static final float LERP_SPEED_INTERSECT_X2 = 0.65f;
    private static final float LERP_SPEED_NORMAL_X1 = 0.85f;
    private static final float LERP_SPEED_NORMAL_X2 = 0.95f;
    private static final float LERP_ALPHA_ZX = 0.9f;
    private static final float LERP_ALPHA_ZX2 = 0.7f;
    private static final float LERP_ALPHA_ZX3 = 0.98f;
    private static final float LERP_ALPHA_ZX4 = 0.91f;
    private static final float LERP_SPEED_INTERSECT_Z1 = 0.35f;
    private static final float LERP_SPEED_INTERSECT_Z2 = 0.65f;
    private static final float LERP_SPEED_NORMAL_Z1 = 0.85f;
    private static final float LERP_SPEED_NORMAL_Z2 = 0.95f;
    private static final float AIM_TIMER_LOW = 160.0f;
    private static final float AIM_TIMER_HIGH = 190.0f;
    private static final double HEIGHT_SCALE_FACTOR = 0.5d;
    private static final float LERP_ALPHA_Y_LOW = 0.29f;
    private static final float LERP_ALPHA_Y_HIGH = 0.45f;
    private static final float LERP_ALPHA_Y_2 = 0.69f;
    private static final float Y_TIMER_LOW = 55.0f;
    private static final float Y_TIMER_HIGH = 75.0f;
    private static final float LERP_ALPHA_ORIGIN_LOW = 0.15f;
    private static final float LERP_ALPHA_ORIGIN_HIGH = 0.35f;

    // --- распределения случайных чисел ---
    private static final double GAUSSIAN_SIGMA = 0.02d;
    private static final double SKEW_EXPONENT = 0.7d;
    private static final double SKEW_SCALE = 0.8d;
    private static final double SKEW_OFFSET = 0.1d;
    private static final double LOG_SCALE = 3.0d;
    private static final double LOG_MULT = 0.5d;
    private static final double LOG_BASE = 0.5d;

    private static final float PANEL_WIDTH = 1.55f;
    private static final float PANEL_HEIGHT = 1.85f;
    private static final float SMOOTH_X_DEFAULT = 0.38f;
    private static final float SMOOTH_X_MAX = 0.55f;
    private static final float SMOOTH_Z_DEFAULT = 0.38f;
    private static final float SMOOTH_Z_MAX = 0.55f;

    private static final float SNAP_ANGLE_THRESHOLD = 20.0f;

    private static SecureRandom random = new SecureRandom();
    private static Vec3d aimPoint = Vec3d.ZERO;
    private static Vec3d eyeAnchor = Vec3d.ZERO;
    private static long lastAimUpdateTime = 0L;
    private static float smoothX;
    private static float smoothZ;
    private static float heightDivisor;
    private static boolean invertActive;
    private static boolean aimInitialized;
    private static int snapTicks;
    private static float lastYaw;
    private static float lastPitch;

    public static void reset() {
        random = new SecureRandom();
        aimPoint = Vec3d.ZERO;
        eyeAnchor = Vec3d.ZERO;
        lastAimUpdateTime = 0L;
        heightDivisor = randomRange(PANEL_WIDTH, PANEL_HEIGHT);
        smoothX = randomRange(SMOOTH_X_DEFAULT, SMOOTH_X_MAX);
        smoothZ = randomRange(SMOOTH_Z_DEFAULT, SMOOTH_Z_MAX);
        invertActive = false;
        aimInitialized = false;
        snapTicks = 0;
        lastYaw = 0.0f;
        lastPitch = 0.0f;
    }

    public static void updateRotation(LivingEntity target, float attackRange, float snappiness) {
        if (mc.player == null || mc.world == null) {
            return;
        }
        Vec3d vec = computeTargetVector(target);
        float oscillation = (float) Math.ceil(randomRange(YAW_RANGE_MIN, YAW_RANGE_MAX)
                * Math.cos((double) System.currentTimeMillis() / OSCILLATION_PERIOD));
        if (INVERT_OSCILLATION) {
            oscillation = -oscillation;
        }
        float currentYaw = mc.player.getYaw();
        float currentPitch = mc.player.getPitch();
        boolean rotationSnap = MathHelper.abs(currentYaw - lastYaw) > SNAP_ANGLE_THRESHOLD
                || MathHelper.abs(currentPitch - lastPitch) > SNAP_ANGLE_THRESHOLD;
        lastYaw = currentYaw;
        lastPitch = currentPitch;
        snapTicks = rotationSnap ? 0 : snapTicks + 1;
        float snap = (float) snapTicks;
        if (snap > randomRange(2.0f, SNAP_TICKS_LOW) && snap < randomRange(SNAP_TICKS_HIGH, SNAP_TICKS_MAX)) {
            oscillation += randomRange(SNAP_OFFSET_VALUE, 1.0f);
        }
        float yaw = (float) MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(vec.z, vec.x)) - BASE_YAW_OFFSET)
                + oscillation;
        float pitch = (float) (-Math.toDegrees(Math.atan2(vec.y, Math.hypot(vec.x, vec.z))));
        Box targetBox = target.getBoundingBox();
        boolean intersects = mc.player.getBoundingBox().intersects(targetBox);
        boolean inRayCast = AuraUtil.a(yaw, pitch, (double) attackRange, target, true);
        float speed;
        if (intersects) {
            speed = (mc.player.age % randomRange(2.0f, TICK_MOD_EVEN) == 0.0f)
                    ? (!inRayCast ? randomRange(YAW_OFFSET_A, YAW_OFFSET_B) : 0.0f)
                    : randomRange(YAW_OFFSET_C, YAW_OFFSET_D);
        } else {
            speed = (mc.player.age % randomRange(TICK_MOD_ODD_1, TICK_MOD_ODD_2) == 0.0f)
                    ? (!inRayCast ? randomRange(YAW_OFFSET_E, YAW_OFFSET_F) : 0.0f)
                    : randomRange(YAW_OFFSET_G, YAW_OFFSET_H);
        }
        if (!invertActive && mc.player.age % 760 == 0) {
            invertActive = true;
        }
        speed *= snappiness;
        Delta.getInstance().getModuleProcessor().k().startAimingWithSpeeds(
                new Rotation(yaw, pitch), speed, speed * speed, 1, 12);
    }

    private static Vec3d computeTargetVector(LivingEntity target) {
        boolean intersecting = mc.player.getBoundingBox().intersects(target.getBoundingBox());
        smoothX = (float) MathHelper.lerp(randomRange(INVERT_OSCILLATION ? LERP_ALPHA_INTERSECT_A
                        : LERP_ALPHA_INTERSECT_B, INVERT_OSCILLATION ? LERP_ALPHA_INTERSECT_C : LERP_ALPHA_INTERSECT_D),
                smoothX, intersecting ? randomRange(LERP_SPEED_INTERSECT_X1, LERP_SPEED_INTERSECT_X2)
                        : randomRange(LERP_SPEED_NORMAL_X1, LERP_SPEED_NORMAL_X2));
        smoothZ = (float) MathHelper.lerp(randomRange(INVERT_OSCILLATION ? LERP_ALPHA_ZX : LERP_ALPHA_ZX2,
                        INVERT_OSCILLATION ? LERP_ALPHA_ZX3 : LERP_ALPHA_ZX4),
                smoothZ, intersecting ? randomRange(LERP_SPEED_INTERSECT_Z1, LERP_SPEED_INTERSECT_Z2)
                        : randomRange(LERP_SPEED_NORMAL_Z1, LERP_SPEED_NORMAL_Z2));
        if (!aimInitialized) {
            aimPoint = target.getEyePos();
            aimInitialized = true;
        }
        double targetX = target.getX();
        double targetZ = target.getZ();
        Vec3d eye = mc.player.getEyePos();
        if (eyeAnchor == Vec3d.ZERO) {
            eyeAnchor = eye;
        }
        boolean heightDiff = Math.abs(target.getY() - mc.player.getY()) > 1.0d;
        long now = System.currentTimeMillis();
        if ((float) (now - lastAimUpdateTime) > randomRange(AIM_TIMER_LOW, AIM_TIMER_HIGH)) {
            lastAimUpdateTime = now;
            double targetY = target.getY()
                    + (heightDiff ? (double) target.getHeight() * HEIGHT_SCALE_FACTOR
                    : (double) (target.getHeight() / heightDivisor));
            aimPoint = new Vec3d(aimPoint.x,
                    MathHelper.lerp((double) randomRange(LERP_ALPHA_Y_LOW, heightDiff ? LERP_ALPHA_Y_HIGH
                            : LERP_ALPHA_Y_2), aimPoint.y, targetY),
                    aimPoint.z);
        }
        if ((float) (now - lastAimUpdateTime) > randomRange(Y_TIMER_LOW, Y_TIMER_HIGH)) {
            eyeAnchor = new Vec3d(eyeAnchor.x,
                    MathHelper.lerp((double) randomRange(LERP_ALPHA_ORIGIN_LOW, LERP_ALPHA_ORIGIN_HIGH),
                            eyeAnchor.y, eye.y),
                    eyeAnchor.z);
        }
        eyeAnchor = new Vec3d(MathHelper.lerp((double) smoothX, eyeAnchor.x, eye.x), eyeAnchor.y,
                MathHelper.lerp((double) smoothZ, eyeAnchor.z, eye.z));
        aimPoint = new Vec3d(MathHelper.lerp((double) smoothX, aimPoint.x, targetX), aimPoint.y,
                MathHelper.lerp((double) smoothZ, aimPoint.z, targetZ));
        return aimPoint.subtract(eyeAnchor);
    }

    private static float randomSecureRange(float a, float b) {
        return a + (b - a) * random.nextFloat();
    }

    private static float randomMathRange(float a, float b) {
        return a + (b - a) * (float) Math.random();
    }

    private static float randomBiasedRange(float a, float b) {
        float r1 = random.nextFloat();
        float r2 = random.nextFloat();
        return a + (b - a) * ((r1 + r2) / 2.0f);
    }

    private static float randomGaussianRange(float a, float b) {
        double d = random.nextDouble();
        double d2 = random.nextDouble();
        double d3 = random.nextGaussian() * GAUSSIAN_SIGMA;
        double d4 = Math.pow(d, 1.0d + random.nextDouble() * SKEW_EXPONENT);
        double d5 = (d2 * SKEW_SCALE + SKEW_OFFSET) * (Math.log1p(d * LOG_SCALE) * LOG_MULT + LOG_BASE);
        return (float) ((double) a + (double) (b - a) * d4 * d5 + d3);
    }

    public static float randomRange(float a, float b) {
        if (b < a) {
            float t = a;
            a = b;
            b = t;
        }
        if (b == a) {
            return a;
        }
        float value;
        switch (random.nextInt(4)) {
            case 0:
                value = randomBiasedRange(a, b);
                break;
            case 1:
                value = randomGaussianRange(a, b);
                break;
            case 2:
                value = randomMathRange(a, b);
                break;
            default:
                value = randomSecureRange(a, b);
                break;
        }
        if (!Float.isFinite(value)) {
            value = a;
        }
        return MathHelper.clamp(value, a, b);
    }
}
