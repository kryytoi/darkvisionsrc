package aethereal.module.movement;

import aethereal.core.Category;
import aethereal.core.Module;
import aethereal.core.ModuleRegister;

@ModuleRegister(name = "Water Jump", description = "Подбрасывает вас вверх при попадании на сыпучий блок под водой", category = Category.Movement)
public class WaterJump extends Module {
}
