package aethereal.module.movement.speed;

import aethereal.core.Category;
import aethereal.core.EventTarget;
import aethereal.core.Module;
import aethereal.core.ModuleRegister;
import aethereal.event.InputEvent;
import aethereal.event.TickEvent;
import aethereal.setting.BooleanSetting;
import aethereal.setting.ModeSetting;
import aethereal.setting.SliderSetting;
import aethereal.util.MoveUtil;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.tick.TickManager;

import java.util.concurrent.ThreadLocalRandom;

@ModuleRegister(name = "Speed", description = "Ускоряет движение с обходом ReallyWorld", category = Category.Movement)
public class Speed extends Module {
    private static final float BASE_TICK_RATE = 20.0f;
    private static final float TIMER_BOOST = 1.05f;
    private static final float TICK_RATE_STEP = 0.25f;
    private static final float GROUND_SPEED = 0.281f;

    private final ModeSetting bypass = new ModeSetting("Тип обхода", "ReallyWorld", "ReallyWorld");
    private final SliderSetting speedMultiplier = new SliderSetting("Speed Multiplier", 1.6f, 1.0f, 3.0f, 0.05f);
    private final SliderSetting frictionModifier = new SliderSetting("Friction Modifier", 0.98f, 0.90f, 0.999f, 0.001f);
    private final SliderSetting yMotionBoost = new SliderSetting("Y-Motion Boost", 0.42f, 0.0f, 0.6f, 0.01f);
    private final BooleanSetting smartAirFriction = new BooleanSetting("Smart Air-Friction", true);
    private final BooleanSetting strafeCheck = new BooleanSetting("Strafe Check", true);

    public Speed() {
        a(this.bypass, this.speedMultiplier, this.frictionModifier, this.yMotionBoost, this.smartAirFriction,
                this.strafeCheck);
    }

    @Override
    public void b() {
        super.b();
    }

    @Override
    public void c() {
        super.c();
        restoreTimer();
    }

    @EventTarget
    public void a(InputEvent event) {
        if (mc.player == null || mc.world == null || !isReallyWorld() || event.isSneak()) {
            return;
        }
        if (event.getForward() == 0.0f && event.getStrafe() == 0.0f) {
            return;
        }
        if (this.strafeCheck.c() && event.getForward() != 0.0f && event.getStrafe() != 0.0f) {
            MoveUtil.a(event, mc.player.getYaw(), 1);
        }
    }

    @EventTarget
    public void a(TickEvent event) {
        if (mc.player == null || mc.world == null) {
            restoreTimer();
            return;
        }
        if (!isReallyWorld() || isSuspended()) {
            restoreTimer();
            return;
        }
        handleMovement();
        handleTimer();
    }

    private boolean isReallyWorld() {
        return this.bypass.l("ReallyWorld");
    }

    private boolean isSuspended() {
        if (mc.player.isTouchingWater() || mc.player.isInLava() || mc.player.hasVehicle() || mc.player.isGliding()
                || mc.player.horizontalCollision
                || mc.player.hasStatusEffect(StatusEffects.BLINDNESS)
                || mc.player.hasStatusEffect(StatusEffects.SLOWNESS)) {
            return true;
        }
        BlockPos pos = mc.player.getBlockPos();
        BlockState state = mc.world.getBlockState(pos);
        return state.isOf(Blocks.COBWEB) || state.isOf(Blocks.SLIME_BLOCK);
    }

    private void handleMovement() {
        Vec3d velocity = mc.player.getVelocity();
        float multiplier = this.speedMultiplier.c().floatValue();
        float friction = this.frictionModifier.c().floatValue();
        double targetSpeed = (double) GROUND_SPEED * (double) multiplier;
        boolean hasInput = mc.player.input.movementForward != 0.0f || mc.player.input.movementSideways != 0.0f;
        if (mc.player.isOnGround()) {
            handleGround(velocity, hasInput, targetSpeed);
            return;
        }
        double hSpeed = Math.hypot(velocity.x, velocity.z);
        if (hSpeed < 1.0E-5d) {
            if (hasInput) {
                applyDirectionalImpulse(targetSpeed, 0.0d);
            }
            return;
        }
        double scale;
        if (!hasInput || (this.smartAirFriction.c() && hSpeed > targetSpeed)) {
            scale = (double) friction;
        } else if (this.smartAirFriction.c() && hSpeed < targetSpeed) {
            scale = 1.0d + (targetSpeed - hSpeed) / hSpeed * 0.15d;
        } else {
            scale = 1.0d + ((double) friction - 1.0d) * 0.25d;
        }
        scale = Math.min(scale, targetSpeed / hSpeed + 0.05d);
        Vec3d scaled = velocity.multiply(scale, 1.0d, scale).add(gaussNoise(), 0.0d, gaussNoise());
        mc.player.setVelocity(scaled.x, velocity.y, scaled.z);
    }

    private void handleGround(Vec3d velocity, boolean hasInput, double targetSpeed) {
        if (!hasInput) {
            Vec3d slowed = velocity.multiply(0.6d, 1.0d, 0.6d).add(gaussNoise(), 0.0d, gaussNoise());
            mc.player.setVelocity(slowed.x, velocity.y, slowed.z);
            return;
        }
        double boost = (double) this.yMotionBoost.c().floatValue();
        double yMotion = 0.0d;
        if (mc.options.jumpKey.isPressed()) {
            mc.player.jump();
        } else if (boost > 0.0d) {
            yMotion = boost;
        }
        double safe = 0.95d + (double) ThreadLocalRandom.current().nextFloat() * 0.05d;
        applyDirectionalImpulse(targetSpeed * safe, yMotion);
    }

    private void applyDirectionalImpulse(double speed, double yMotion) {
        float forward = mc.player.input.movementForward;
        float strafe = mc.player.input.movementSideways;
        float yaw = mc.player.getYaw();
        float offset;
        if (forward > 0.0f) {
            offset = strafe > 0.0f ? -45.0f : strafe < 0.0f ? 45.0f : 0.0f;
        } else if (forward < 0.0f) {
            offset = strafe > 0.0f ? -135.0f : strafe < 0.0f ? 135.0f : 180.0f;
        } else {
            offset = strafe > 0.0f ? -90.0f : strafe < 0.0f ? 90.0f : 0.0f;
        }
        double radians = Math.toRadians((double) yaw + 90.0d + (double) offset);
        double motionX = Math.cos(radians) * ((double) forward) * speed
                + Math.sin(radians) * ((double) strafe) * speed;
        double motionZ = Math.sin(radians) * ((double) forward) * speed
                - Math.cos(radians) * ((double) strafe) * speed;
        mc.player.setVelocity(motionX, yMotion, motionZ);
    }

    private void handleTimer() {
        float target;
        if (mc.player.isOnGround() || (mc.player.input.movementForward == 0.0f
                && mc.player.input.movementSideways == 0.0f)) {
            target = BASE_TICK_RATE;
        } else {
            target = BASE_TICK_RATE * TIMER_BOOST;
        }
        TickManager tickManager = mc.world.getTickManager();
        float current = tickManager.getTickRate();
        if (current < target) {
            tickManager.setTickRate(Math.min(current + TICK_RATE_STEP, target));
        } else if (current > target) {
            tickManager.setTickRate(Math.max(current - TICK_RATE_STEP, target));
        }
    }

    private void restoreTimer() {
        if (mc.world != null && mc.world.getTickManager() != null) {
            mc.world.getTickManager().setTickRate(BASE_TICK_RATE);
        }
    }

    private double gaussNoise() {
        double amplitude = 0.001d + (double) ThreadLocalRandom.current().nextFloat() * 0.002d;
        return ThreadLocalRandom.current().nextGaussian() * amplitude;
    }
}
