package platform.inject.mixin;

import aethereal.ui.theme.DarkVisionUI;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({MultiplayerScreen.class})
public class DarkVisionMultiplayerMixin {
    @Inject(method = {"render"}, at = {@At("TAIL")})
    private void dvRender(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        DarkVisionUI.a(context, "Сетевые игры");
    }
}
