package platform.inject.mixin;

import aethereal.core.Interface;
import aethereal.ui.theme.DarkVisionUI;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Screen.class})
public class DarkVisionScreenBackgroundMixin {
    @Inject(method = {"renderBackground"}, at = {@At("HEAD")}, cancellable = true)
    private void dvRenderBackground(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        Screen self = (Screen) (Object) this;
        if (!DarkVisionUI.a(self)) {
            return;
        }
        int width = Interface.mc.getWindow().getScaledWidth();
        int height = Interface.mc.getWindow().getScaledHeight();
        DarkVisionUI.a(context, width, height, mouseX, mouseY);
        ci.cancel();
    }
}
