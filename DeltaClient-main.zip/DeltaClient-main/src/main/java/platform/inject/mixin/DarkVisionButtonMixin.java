package platform.inject.mixin;

import aethereal.ui.theme.DarkVisionUI;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.PressableWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({PressableWidget.class})
public class DarkVisionButtonMixin {
    @Inject(method = {"renderWidget"}, at = {@At("HEAD")}, cancellable = true)
    private void dvRenderWidget(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!DarkVisionUI.a()) {
            return;
        }
        if (((Object) this) instanceof ButtonWidget button) {
            ci.cancel();
            DarkVisionUI.a(context, button, mouseX, mouseY);
        }
    }
}
