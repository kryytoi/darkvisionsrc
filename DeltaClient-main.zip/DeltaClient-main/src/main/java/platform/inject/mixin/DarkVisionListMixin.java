package platform.inject.mixin;

import aethereal.core.Delta;
import aethereal.render.Draw2DProcessor;
import aethereal.ui.theme.DarkVisionUI;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.EntryListWidget;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({EntryListWidget.class})
public class DarkVisionListMixin {
    @Inject(method = {"drawMenuListBackground"}, at = {@At("HEAD")}, cancellable = true)
    private void dvMenuListBackground(DrawContext context, CallbackInfo ci) {
        if (!DarkVisionUI.a()) {
            return;
        }
        EntryListWidget<?> self = (EntryListWidget<?>) (Object) this;
        int x = self.getX();
        int y = self.getY();
        int w = self.getWidth();
        int h = self.getHeight();
        ci.cancel();
        MatrixStack matrices = context.getMatrices();
        Draw2DProcessor draw = Delta.getInstance().getModuleProcessor().i();
        draw.a(matrices, x, y, w, h, 6.0f, DarkVisionUI.PANEL);
        draw.a(matrices, x, y, w, h, 6.0f, 1.0f, DarkVisionUI.PANEL_BORDER);
    }

    @Inject(method = {"drawSelectionHighlight"}, at = {@At("HEAD")}, cancellable = true)
    private void dvSelectionHighlight(DrawContext context, int top, int rowWidth, int rowHeight, int color, int hoverColor, CallbackInfo ci) {
        if (!DarkVisionUI.a()) {
            return;
        }
        EntryListWidget<?> self = (EntryListWidget<?>) (Object) this;
        int x = self.getX() + ((self.getWidth() - rowWidth) / 2);
        ci.cancel();
        MatrixStack matrices = context.getMatrices();
        Draw2DProcessor draw = Delta.getInstance().getModuleProcessor().i();
        draw.a(matrices, x, (top - 1.0f), rowWidth, (rowHeight + 2.0f), 4.0f, DarkVisionUI.ROW_SELECTED);
        context.fill(x + 2, top + 2, x + 4, top + rowHeight - 2, DarkVisionUI.ACCENT);
    }
}
