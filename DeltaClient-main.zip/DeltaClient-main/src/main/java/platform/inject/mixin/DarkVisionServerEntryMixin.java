package platform.inject.mixin;

import aethereal.render.Fonts;
import aethereal.ui.theme.DarkVisionUI;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerServerListWidget;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin({MultiplayerServerListWidget.ServerEntry.class})
public class DarkVisionServerEntryMixin {
    @Shadow
    public ServerInfo server;

    @Shadow
    public List<Text> playerListSummary;

    @Inject(method = {"render"}, at = {@At("HEAD")}, cancellable = true)
    private void dvRender(DrawContext context, int entryIndex, int topPos, int leftPos, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float delta, CallbackInfo ci) {
        if (!DarkVisionUI.a()) {
            return;
        }
        ci.cancel();
        DarkVisionUI.a(context, leftPos, topPos, entryWidth, entryHeight, false, hovered);
        DarkVisionUI.drawIcon(context, leftPos, topPos, DarkVisionUI.serverIconId(this.server), true);
        MatrixStack matrices = context.getMatrices();
        String name = (this.server.name == null || this.server.name.isEmpty()) ? this.server.address : this.server.name;
        Fonts.e.a(matrices, name, leftPos + 35, topPos + 2, 9.0f,
                hovered ? 0xFFFFFFFF : DarkVisionUI.TEXT_SOFT);
        Text motd = this.server.label;
        if ((motd != null) && !motd.getString().isEmpty()) {
            String motdStr = motd.getString();
            int maxChars = Math.max(8, ((entryWidth - 48) / 7));
            if (motdStr.length() > maxChars) {
                motdStr = motdStr.substring(0, maxChars) + "…";
            }
            Fonts.e.a(matrices, motdStr, leftPos + 35, topPos + 14, 7.5f, 0xFFB8B8C8);
        }
        if (this.playerListSummary != null) {
            StringBuilder players = new StringBuilder();
            for (Text text : this.playerListSummary) {
                if (players.length() > 0) {
                    players.append("  ");
                }
                players.append(text.getString());
            }
            if (players.length() > 0) {
                Fonts.e.a(matrices, players.toString(), leftPos + 35, topPos + entryHeight - 10, 7.5f, DarkVisionUI.TEXT_DIM);
            }
        }
        long ping = this.server.ping;
        if (ping >= 0L) {
            String pingText = ping + " ms";
            int pingColor = ping < 100L ? 0xFF50FA7B : (ping < 250L ? 0xFFFACC15 : 0xFFF87171);
            Fonts.e.a(matrices, pingText, leftPos + entryWidth - 12 - Fonts.e.a(pingText, 7.5f), topPos + entryHeight - 10, 7.5f, pingColor);
        }
    }
}
