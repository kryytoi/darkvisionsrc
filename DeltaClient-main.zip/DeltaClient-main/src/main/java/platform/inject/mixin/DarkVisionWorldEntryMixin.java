package platform.inject.mixin;

import aethereal.render.Fonts;
import aethereal.ui.theme.DarkVisionUI;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.world.WorldListWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.world.GameMode;
import net.minecraft.world.level.storage.LevelSummary;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({WorldListWidget.WorldEntry.class})
public class DarkVisionWorldEntryMixin {
    @Shadow
    public LevelSummary level;

    @Shadow
    public WorldListWidget field_19135;

    @Inject(method = {"render"}, at = {@At("HEAD")}, cancellable = true)
    private void dvRender(DrawContext context, int entryIndex, int topPos, int leftPos, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float delta, CallbackInfo ci) {
        if (!DarkVisionUI.a()) {
            return;
        }
        ci.cancel();
        boolean selected = (this.field_19135 != null) && (this.field_19135.getSelectedOrNull() == (Object) this);
        DarkVisionUI.a(context, leftPos, topPos, entryWidth, entryHeight, false, hovered);
        DarkVisionUI.drawIcon(context, leftPos, topPos, DarkVisionUI.worldIconId(this.level), false);
        MatrixStack matrices = context.getMatrices();
        Fonts.e.a(matrices, this.level.getDisplayName(), leftPos + 35, topPos + 2, 9.0f,
                (selected || hovered) ? 0xFFFFFFFF : DarkVisionUI.TEXT_SOFT);
        StringBuilder info = new StringBuilder("Обновлён: " + DarkVisionUI.a(this.level.getLastPlayed()));
        GameMode mode = this.level.getGameMode();
        if ((mode != null) && (mode != GameMode.SURVIVAL) && (mode != GameMode.DEFAULT)) {
            info.append("  ·  ").append(mode.getTranslatableName().getString());
        }
        if (this.level.hasCheats()) {
            info.append("  ·  Читы");
        }
        Fonts.e.a(matrices, info.toString(), leftPos + 35, topPos + 13, 7.5f, DarkVisionUI.TEXT_DIM);
    }
}
